@extends('app.base')

@section('content')
  <main id="main" class="main">
    <form action="{{ url('profesor/' . $profesor->id) }}" method="post">

    @csrf
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Añadir profesor</h5>
        <form class="row g-3" action="{{ url('profesor') }}" method="post">
          <div class="col-12">
            <label for="userseneca" class="form-label">Usuario Seneca</label>
            <input type="text" class="form-control" id="userseneca" name="userseneca" minlength="3" maxlength="30" required> 
          </div>
          <div class="col-12">
            <label for="nombre" class="form-label">Nombre</label>
            <input type="text" class="form-control" id="nombre" name="nombre" minlength="3" maxlength="30" required>
          </div>
          <div class="col-12">
            <label for="apellido1" class="form-label">Apellido1</label>
            <input type="text" class="form-control" id="apellido1" name="apellido1" minlength="3" maxlength="30" required>
          </div>
          <div class="col-12">
            <label for="apellido2" class="form-label">Apellido2</label>
            <input type="text" class="form-control" id="apellido2" name="apellido2" minlength="3" maxlength="30">
          </div>
          <div class="col-12">
            <label for="especialidad" class="form-label">Especialidad</label>
            <select class="form-select" aria-label="Default select example" required>
                      <option selected disabled>Selecciona tu especialidad</option>
                      <option value="informatico">Informatico</option>
                      <option value="sistema">Sistema</option>
            </select>
          </div>
          <div class="col-12">
            <label for="lecciones" class="form-label">Lecciones</label>
            <input type="text" class="form-control" id="lecciones" name="lecciones" minlength="3" maxlength="30">
          </div>
          <div class="text-center">
            <button type="submit" class="btn btn-primary">Añadir</button>
            <a href="{{ url('profesor') }}" class="btn btn-primary"><i class="bi bi-arrow-return-left"></i></a>
          </div>
        </form>
      </div>
    </div>
    </form>
  </main>

@endsection