@extends('app.base')

@section('content')
<main id="main" class="main">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Profesor . {{ $profesor->nombre}}</h5>
        <ul class="list-group">
          <li class="list-group-item">ID: {{$profesor->id}}</li>
          <li class="list-group-item">Usuario Seneca: {{$profesor->userseneca}}</li>
          <li class="list-group-item">Nombre: {{$profesor->nombre}}</li>
          <li class="list-group-item">Apellido1:{{$profesor->apellido1}}</li>
          <li class="list-group-item">Apellido2:{{$profesor->apellido2}}</li>
          <li class="list-group-item">Especialidad: {{$profesor->especialidad}}</li>
          <li class="list-group-item">Lecciones: {{$profesor->lecciones}}</li>
        </ul>
        <a class="btn btn-dark" href="{{ url('profesor/' . $profesor->id . '/edit') }}"><i class="ri-edit-2-fill"></i></a>
        <a data-url="{{ url('profesor/' . $profesor->id) }}" class="btn btn-danger hrefDelete" href="{{ url('profesor') }}"><i class="bi bi-trash"></i></a>
        <a href="{{ url('profesor') }}" class="btn btn-primary"><i class="bi bi-arrow-return-left"></i></a>
      </div>
    </div>
  </main>
@endsection