@extends('app.base')

@section('content')
<main id="main" class="main">
    Index
</main>
@endsection