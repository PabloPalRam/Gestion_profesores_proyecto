@extends('app.base')

@section('content')
<main id="main" class="main">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Modulo . {{ $modulo->nombre}}</h5>
        <ul class="list-group">
          <li class="list-group-item">ID: . {{$modulo->id}}</li>
          <li class="list-group-item">Formación: . {{$modulo->formacion}}</li>
          <li class="list-group-item">Denominacion: . {{$modulo->denominacion}}</li>
          <li class="list-group-item">Siglas: . {{$modulo->siglas}}</li>
          <li class="list-group-item">Curso: . {{$modulo->curso}}</li>
          <li class="list-group-item">Horas: . {{$modulo->horas}}</li>
          <li class="list-group-item">Especialidades: . {{$modulo->especialidades}}</li>
          <li class="list-group-item">Lecciones: . {{$modulo->lecciones}}</li>
        </ul>
        <a class="btn btn-dark" href="{{ url('modulo/' . $modulo->id . '/edit') }}"><i class="ri-edit-2-fill"></i></a>
        <a data-url="{{ url('modulo/' . $modulo->id) }}" class="btn btn-danger hrefDelete" href="{{ url('modulo') }}"><i class="bi bi-trash"></i></a>
        <a href="{{ url('modulo') }}" class="btn btn-primary"><i class="bi bi-arrow-return-left"></i></a>
      </div>
    </div>
  </main>
@endsection
