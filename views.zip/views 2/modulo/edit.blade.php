@extends('app.base')

@section('content')
  <main id="main" class="main">
    <form action="{{ url('modulo/' . $modulo->id) }}" method="post">

    @method('put')
    @csrf
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Editar modulo</h5>
        <form class="row g-3" action="{{ url('modulo') }}" method="post">
          <div class="col-12">
            <label for="formacion" class="form-label">Formación</label>
            <input type="text" class="form-control" id="formacion" name="formacion" minlength="3" maxlength="30" required value="{{ old('formacion', $modulo->formacion) }}">
          </div>
          <div class="col-12">
            <label for="denominacion" class="form-label">denominacion</label>
            <input type="text" class="form-control" id="denominacion" name="denominacion" minlength="3" maxlength="30" required value="{{ old('denominacion', $modulo->denominacion) }}">
          </div>
          <div class="col-12">
            <label for="siglas" class="form-label">siglas</label>
            <input type="text" class="form-control" id="siglas" name="siglas" minlength="3" maxlength="30" required value="{{ old('siglas', $modulo->siglas) }}">
          </div>
          <div class="col-12">
            <label for="curso" class="form-label">curso</label>
            <input type="text" class="form-control" id="curso" name="curso" minlength="3" maxlength="30" value="{{ old('curso', $modulo->curso) }}">
          </div>
          <div class="col-12">
            <label for="horas" class="form-label">horas</label>
            <input type="text" class="form-control" id="horas" name="horas" minlength="3" maxlength="30" value="{{ old('horas', $modulo->horas) }}">
          </div>
          <div class="col-12">
            <label for="especialidades" class="form-label">especialidades</label>
            <input type="text" class="form-control" id="especialidades" name="especialidades" minlength="3" maxlength="30" value="{{ old('especialidades', $modulo->especialidades) }}">
          </div>
          <div class="col-12">
            <label for="lecciones" class="form-label">Lecciones</label>
            <input type="text" class="form-control" id="lecciones" name="lecciones" minlength="3" maxlength="30" value="{{ old('lecciones', $modulo->lecciones) }}">
          </div>
          <div class="text-center">
            <button type="submit" class="btn btn-primary">Añadir</button>
            <a href="{{ url('modulo') }}" class="btn btn-primary"><i class="bi bi-arrow-return-left"></i></a>
          </div>
        </form>
      </div>
    </div>
    </form>
  </main>

@endsection