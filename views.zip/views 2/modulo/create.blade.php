@extends('app.base')

@section('content')
  <main id="main" class="main">
    <form action="{{ url('modulo/' . $modulo->id) }}" method="post">

    @csrf
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Editar modulo</h5>
        <form class="row g-3" action="{{ url('modulo') }}" method="post">
          <div class="col-12">
            <label for="formacion" class="form-label">Formación</label>
            <input type="text" class="form-control" id="formacion" name="formacion" minlength="3" maxlength="30" required>
          </div>
          <div class="col-12">
            <label for="denominacion" class="form-label">Denominacion</label>
            <input type="text" class="form-control" id="denominacion" name="denominacion" minlength="3" maxlength="30" required>
          </div>
          <div class="col-12">
            <label for="siglas" class="form-label">Siglas</label>
            <input type="text" class="form-control" id="siglas" name="siglas" minlength="3" maxlength="30" required>
          </div>
          <div class="col-12">
            <label for="curso" class="form-label">Curso</label>
            <input type="text" class="form-control" id="curso" name="curso" minlength="3" maxlength="30">
          </div>
          <div class="col-12">
            <label for="horas" class="form-label">Horas</label>
            <input type="number" class="form-control" id="horas" name="horas" step="0.1">
          </div>
          <div class="col-12">
            <label for="especialidades" class="form-label">Especialidades</label>
            <input type="text" class="form-control" id="especialidades" name="especialidades" minlength="3" maxlength="30">
          </div>
          <div class="col-12">
            <label for="lecciones" class="form-label">Lecciones</label>
            <input type="text" class="form-control" id="lecciones" name="lecciones" minlength="3" maxlength="30">
          </div>
          <div class="text-center">
            <button type="submit" class="btn btn-primary">Añadir</button>
            <a href="{{ url('modulo') }}" class="btn btn-primary"><i class="bi bi-arrow-return-left"></i></a>
          </div>
        </form>
      </div>
    </div>
    </form>
  </main>

@endsection