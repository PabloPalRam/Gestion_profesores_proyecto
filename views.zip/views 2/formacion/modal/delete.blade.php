<div class="modal fade" id="largeModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Borrar formación</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p>Seguro que desea borrar . {{ $formacion->siglas }}</p>
        <input type="hidden" class="form-control" id="denominacion" name="denominacion" minlength="3" maxlength="30" required>
        <input type="hidden" class="form-control" id="siglas" name="siglas" minlength="3" maxlength="30" required>
        <input class="form-control" type="hidden" id="deleteUrl">
        <div class="alert alert-danger visually-hidden" role="alert" id="errorAlert">
          Error al borrar la nueva formación...
        </div>      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary">Borrar</button>
      </div>
    </div>
  </div>
</div>

