<div class="modal fade" id="largeModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Editar formación</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <input type="text" class="form-control" id="denominacion" name="denominacion" minlength="3" maxlength="30" required value="{{ old('denominacion', $formacion->denominacion) }}">
        <input type="text" class="form-control" id="siglas" name="siglas" minlength="3" maxlength="30" required value="{{ old('siglas', $formacion->siglas) }}">
        <div class="alert alert-danger visually-hidden" role="alert" id="errorAlert">
          Error al editar la nueva formación...
        </div>      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary">Editar</button>
      </div>
    </div>
  </div>
</div>