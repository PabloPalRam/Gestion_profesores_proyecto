@extends('app.base')

@section('title', 'Tabla formación')

@include('modal.create')
@include('modal.edit')
@include('modal.delete')

<script>
  /* global fetch */
  let btCrearFormacion = document.getElementById('btCrearFormacion');
  const csrf = document.querySelector('meta[name="csrf-token"]')['content'];
  let code = document.getElementById('code');
  let name = document.getElementById('name');
  const url = document.querySelector('meta[name="url-base"]')['content'];
  btCrearFormacion.onclick = function() {
    let data = {
      code: code.value,
      name: name.value,
    };
    //es el momento de validar en js
    llamadaAjax(data);
  };
  function llamadaAjax(data) {
    fetch(url + '/pais', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-CSRF-TOKEN': csrf
      },
      body: JSON.stringify(data),
    })
    .then(response => response.json())
    .then(data => {
      console.log(data);
    })
    .catch(error => console.error("Error:", error));
  }
</script>


@section('content')
<main id="main" class="main">
<a class="btn-info btn" href="{{ url('formacion/create') }}">Añadir formación</a>
<table class="table datatable">
        <thead>
        <tr>
            <th>ID</th>
            <th>Denominacion</th>
            <th>Siglas</th>
        </tr>
    </thead>
    <tbody>
        @foreach($formaciones as $formacion)
        <tr>
            <td>{{$formacion->id}}</td>
            <td>{{$formacion->denominacion}}</td>
            <td>{{$formacion->siglas}}</td>
            <td>
                <a class="btn btn-dark" href="{{ url('formacion/' . $formacion->id . '/edit') }}"><i class="ri-edit-2-fill"></i></a>
                <a data-url="{{ url('formacion/' . $formacion->id) }}" class="btn btn-danger hrefDelete" href=""><i class="trash"></i></a>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
</main>

@endsection