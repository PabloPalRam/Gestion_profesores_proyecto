@extends('app.base')

@section('content')
  <main id="main" class="main">
    <form action="{{ url('grupo/' . $grupo->id) }}" method="post">

    @csrf
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Añadir grupo</h5>
        <form class="row g-3" action="{{ url('grupo') }}" method="post">
          <div class="col-12">
            <label for="cursoescolar" class="form-label">Curso escolar</label>
            <input type="text" class="form-control" id="cursoescolar" name="cursoescolar" minlength="3" maxlength="30" required> 
          </div>
          <div class="col-12">
            <label for="formacion" class="form-label">Formacion</label>
            <input type="number" class="form-control" id="formacion" name="formacion" required>
          </div>
          <div class="col-12">
            <label for="curso" class="form-label">Curso</label>
            <input type="text" class="form-control" id="curso" name="curso" minlength="3" maxlength="30" required>
          </div>
          <div class="col-12">
            <label for="denominacion" class="form-label">Denominacion</label>
            <input type="text" class="form-control" id="denominacion" name="denominacion" maxlength="30">
          </div>
          <div class="col-12">
            <label for="turno" class="form-label">Turno</label>
            <select class="form-select" aria-label="Default select example" required>
                      <option selected disabled>Selecciona el turno</option>
                      <option value="informatico">Mañana</option>
                      <option value="sistema">Tarde</option>
            </select>
          </div>
          <div class="text-center">
            <button type="submit" class="btn btn-primary">Añadir</button>
            <a href="{{ url('grupo') }}" class="btn btn-primary"><i class="bi bi-arrow-return-left"></i></a>
          </div>
        </form>
      </div>
    </div>
    </form>
  </main>

@endsection