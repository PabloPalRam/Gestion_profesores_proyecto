import React from 'react';

const DragAndDrop2 = ({ tasks, setTasks, professors, updateProfessorHours }) => {   
    const getList = (list) => {
        return tasks.filter(item => item.list === list)
    }

    const startDrag = (evt, item) => {
        evt.dataTransfer.setData('itemID', item.id)
        console.log(item);
     
    }

    const draggingOver = (evt) => {
        evt.preventDefault();
    }
    const onDeleteButtonClick = (evt, taskId,professorId) => {
        evt.preventDefault();
        const updatedTasks = tasks.map(task => {
            if (task.id === taskId) {
                return { ...task, list: 1 }; // Cambiar el atributo list al valor 1
            }
            return task;
        });
        let horas = document.getElementById('profesor'+professorId)
        let innerhoras = horas.innerHTML
        console.log(innerhoras);
     
        const match = innerhoras.match(/\| (\d+)\/\d+/);
 const resultado = match ? match[1] : null;
 const numero = parseInt(resultado);
 let newAssignedHours = numero-8
     updateProfessorHours(professorId, newAssignedHours);
        setTasks(updatedTasks);
    }

    const onDrop = (evt, list, professorId) => {
        evt.preventDefault();
        const itemID = evt.dataTransfer.getData('itemID');
        const task = tasks.find(task => task.id === Number(itemID));
        if (task) {
            // Si la tarea ya está en la lista del profesor, no hacemos nada
            if (task.list === list) {
                return;
            }
            const updatedTasks = tasks.map(task => {
                if (task.id === Number(itemID)) {
                    return { ...task, list };
                }
                return task;
            });
            setTasks(updatedTasks);

            // Sumar o restar las horas asignadas al profesor
            const professor = professors.find(professor => professor.id === professorId);
            if (professor) {
                const newAssignedHours = professor.assignedHours + (list === 4 ? task.horas : -task.horas);
                updateProfessorHours(professorId, newAssignedHours);
            }
        }
    };

    return ( <>
        <div className="accordion-item">
        <h2 className="accordion-header" id="headingOne">
          <button id='profesor1' className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          {professors[0].name} | {professors[0].assignedHours}/{professors[0].totalHours}
          </button>
        </h2>
        <div id="collapseOne" className="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
          <div className="accordion-body">
          <div id='profesores' className='dd-zone' droppable="true" onDragOver={(evt => draggingOver(evt))} onDrop={(evt => onDrop(evt, 4,1))}>
            {getList(4).map(item => (
                <div className='dd-element' key={item.id} draggable onDragStart={(evt) => startDrag(evt, item,1)}>
                    <strong className='title'>{item.title}</strong>
                    <p className='body'>{item.body}</p>
                    <a data-url="{{ url('modulo/' . $modulo->id) }}" className="btn btn-outline-danger hrefDelete"
                    href="" onClick={(evt) => onDeleteButtonClick(evt, item.id,1)}>
                    <i className="bi bi-x-lg"></i>
                </a>
                    
                </div>
                
            ))}
        </div>
          </div>
        </div>
      </div>
      <div className="accordion-item">
        <h2 className="accordion-header" id="headingTwo">
          <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          {professors[1].name} | {professors[1].assignedHours}/{professors[1].totalHours}
          </button>
        </h2>
        <div id="collapseTwo" className="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
          <div className="accordion-body">
          <div id='profesores' className='dd-zone' droppable="true" onDragOver={(evt => draggingOver(evt))} onDrop={(evt => onDrop(evt, 5))}>
            {getList(5).map(item => (
                <div className='dd-element' key={item.id} draggable onDragStart={(evt) => startDrag(evt, item)}>
                    <strong className='title'>{item.title}</strong>
                    <p className='body'>{item.body}</p>
                    <a data-url="{{ url('modulo/' . $modulo->id) }}" class="btn btn-outline-danger hrefDelete"
                            href=""><i class="bi bi-x-lg"></i></a>
                </div>
            ))}
        </div>
          </div>
        </div>
      </div>
      
      <div className="accordion-item">
                      <h2 className="accordion-header" id="headingThree">
                        <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                          Eva Maria Ruiz | 0/20h
                        </button>
                      </h2>
                      <div id="collapseThree" className="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                        <div className="accordion-body">
                        <div id='profesores' className='dd-zone' droppable="true" onDragOver={(evt => draggingOver(evt))} onDrop={(evt => onDrop(evt, 6))}>
            {getList(6).map(item => (
                <div className='dd-element' key={item.id} draggable onDragStart={(evt) => startDrag(evt, item)}>
                    <strong className='title'>{item.title}</strong>
                    <p className='body'>{item.body}</p>
                    <a data-url="{{ url('modulo/' . $modulo->id) }}" class="btn btn-outline-danger hrefDelete"
                            href=""><i class="bi bi-x-lg"></i></a>
                </div>
            ))}
        </div>
                        </div>
                      </div>
                    </div>
       </>
    )
}

export default DragAndDrop2;
