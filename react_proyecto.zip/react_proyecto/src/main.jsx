import React, { useState } from 'react';

const DragAndDrop = ({ }) => {
    const [tasks, setTasks] = useState([
        { 
            id: 1,
            title: 'DWES',
            body: 'Horas 8',
            horas: 8,
            list: 1
        },
        { 
            id: 2,
            title: 'EIE',
            body: 'Horas 8',
            horas: 8,
            list: 1
        },
        { 
            id: 3,
            title: 'DIWEB',
            body: 'Horas 8',
            horas: 8,
            list: 1
        },
        { 
            id: 4,
            title: 'DWEC',
            body: 'Horas 8',
            horas: 8,
            list: 1
        },
        { 
            id: 5,
            title: 'DAWEB',
            body: 'Horas 8',
            horas: 8,
            list: 1
        },
        { 
          id: 6,
          title: 'HLC',
          body: 'Horas 8',
          horas: 8,
          list: 1
      },
    ]);
    const getList = (list) => {
        return tasks.filter(item => item.list === list)
    }

    const startDrag = (evt, item) => {
        evt.dataTransfer.setData('itemID', item.id)
        console.log(item);
    }

    const draggingOver = (evt) => {
        evt.preventDefault();
    }

    const onDrop = (evt, professorId) => {
        evt.preventDefault();
        const itemID = evt.dataTransfer.getData('itemID');
        const task = tasks.find(task => task.id === Number(itemID)); // Asegurarse de que itemID sea un número
        if (task) {
            const updatedTasks = tasks.map(task => {
                if (task.id === Number(itemID)) {
                    return { ...task, list: professorId };
                }
                return task;
            });
            setTasks(updatedTasks);
            // Actualizar las horas asignadas al profesor
         
        }
    };
    return (
        <div id='profesores' className='dd-zone' droppable="true" onDragOver={(evt => draggingOver(evt))} onDrop={(evt => onDrop(evt, 1))}>
            {getList(1).map(item => (
                <div className='dd-element' key={item.id} draggable onDragStart={(evt) => startDrag(evt, item)}>
                    <strong className='title'>{item.title}</strong>
                    <p className='body'>{item.body}</p>
                    
                </div>
            ))}
        </div>
    )
}

export default DragAndDrop;
